var searchData=
[
  ['s_32',['s',['../classsquare.html#a15acae054fa521d3e1cf105020c6e86f',1,'square']]]
];
