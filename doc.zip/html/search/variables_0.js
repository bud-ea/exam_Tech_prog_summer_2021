var searchData=
[
  ['a_5fx_23',['a_x',['../classsquare.html#a11fd76f933347c67bb461682b32b351e',1,'square::a_x()'],['../classtriangle.html#a3a4cdb2ef864242bfb9ff44e4e419ecc',1,'triangle::a_x()']]],
  ['a_5fy_24',['a_y',['../classsquare.html#a84b4b43fe1b571f9608bc326935cb1f5',1,'square::a_y()'],['../classtriangle.html#aab8f297c5a13b4200cf617062c8fa8ad',1,'triangle::a_y()']]]
];
