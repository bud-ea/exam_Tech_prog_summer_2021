var searchData=
[
  ['triangle_22',['triangle',['../classtriangle.html#aab2adac15175072954ef95e719e2b8d9',1,'triangle']]]
];
