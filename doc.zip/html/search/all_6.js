var searchData=
[
  ['triangle_13',['triangle',['../classtriangle.html',1,'triangle'],['../classtriangle.html#aab2adac15175072954ef95e719e2b8d9',1,'triangle::triangle()']]]
];
