var searchData=
[
  ['c_5fx_27',['c_x',['../classsquare.html#a3e75f76ddf37a87cbf85108b5404d9ec',1,'square::c_x()'],['../classtriangle.html#a9e13815109842d7daa44e7f6523cab69',1,'triangle::c_x()']]],
  ['c_5fy_28',['c_y',['../classsquare.html#a2a8631e98f5ead46e78cb22b7c2b6d35',1,'square::c_y()'],['../classtriangle.html#adee75fa1b901032f52b5b2980d93bae6',1,'triangle::c_y()']]]
];
