var searchData=
[
  ['b_5fx_25',['b_x',['../classsquare.html#ac1b3e9c660a0cfcd033c1680e8050109',1,'square::b_x()'],['../classtriangle.html#a635be43d6df90d986a7a87c63411a955',1,'triangle::b_x()']]],
  ['b_5fy_26',['b_y',['../classsquare.html#a7462258503d8f0989db7005fa21f20ed',1,'square::b_y()'],['../classtriangle.html#a5ea3b68f882a55d75a0a9874a368edda',1,'triangle::b_y()']]]
];
