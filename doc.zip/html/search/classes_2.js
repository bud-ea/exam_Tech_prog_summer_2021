var searchData=
[
  ['triangle_18',['triangle',['../classtriangle.html',1,'']]]
];
